#include <stdio.h>

// Função para calcular o número de Fibonacci e contar as chamadas recursivas
int fib(int n, int *calls) {
    (*calls)++; // Incrementa o contador de chamadas
    if (n == 0 || n == 1) {
        return n;
    } else {
        return fib(n - 1, calls) + fib(n - 2, calls);
    }
}

int main() {
    int T;
    scanf("%d", &T);

    for (int i = 0; i < T; i++) {
        int n;
        scanf("%d", &n);

        int calls = 0;
        int result = fib(n, &calls);

        printf("fib(%d) = %d calls = %d\n", n, calls - 1, result);
    }

    return 0;
}
