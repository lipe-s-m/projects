#include <stdio.h>

// Função recursiva para resolver a Torre de Hanoi e mostrar o passo a passo dos movimentos
void hanoi(int n, int origem, int destino, int auxiliar) {
    if (n == 1) {
        printf("%d %d\n", origem, destino);
    } else {
        hanoi(n - 1, origem, auxiliar, destino);
        printf("%d %d\n", origem, destino);
        hanoi(n - 1, auxiliar, destino, origem);
    }
}

int main() {
    int n;
    scanf("%d", &n);

    hanoi(n, 1, 3, 2);

    return 0;
}
