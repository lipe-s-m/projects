#include<stdio.h>
#include<stdlib.h>

int main(){
    int n, *notas, i, j, k, temp, quinta, trocou=4;
    
    scanf("%d", &n);
    
    notas=(int*)malloc(n*sizeof(int));
    
    for(i=0;i<n;i++){
        scanf("%d", &notas[i]);
    }
    
    for(i=0;i<n;i++){
        for(j=0;j<n-1;j++){
            if(notas[j]>notas[j+1]){
                temp=notas[j];
                notas[j]=notas[j+1];
                notas[j+1]=temp;
            }
        }
    }
     
    quinta=notas[0];

    for(i=1;trocou!=0;i++){
        if(notas[i]>quinta){
            quinta=notas[i];
            trocou--;
        }
    }
    
    
    printf("%d", quinta);
    
    
    return 0;
}