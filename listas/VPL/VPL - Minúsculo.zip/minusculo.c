#include <stdio.h>

int main()
{
    char texto[200];
    int i = 0;
    
    fgets(texto, 200, stdin);
    
    for(i; texto[i] != '\0'; i++)
    {
        if(texto[i] >='A' && texto[i] <= 'Z')
        {
            texto[i] = texto[i] - 'A' + 'a';
        }
    }
    printf("%s", texto);
    return 0;
}