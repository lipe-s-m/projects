#include <stdio.h>
#include <math.h>

int main(){
    
    int n = 0;
    int i = 2;
    
    scanf("%d", &n);
    
    for(i; i <= n; i += 2){
        
        printf("%d^2 = %d\n", i, i * i);
        
    }
    
    
    return 0;
}
