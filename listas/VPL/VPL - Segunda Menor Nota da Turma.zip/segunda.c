#include <stdio.h>

int main(){
    
    int n = 0, i = 0, nota = 0, MAX = 11;
    
    scanf("%d", &n);
    
    for(i; i < n; i++){
        
        scanf("%d", &nota);
        
        if(nota >= 0 && nota < MAX){
            
            if()
            
        }
        
        
    }
    
    return 0;
}
