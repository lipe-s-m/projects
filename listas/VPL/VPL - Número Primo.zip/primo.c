#include <stdio.h>
#include <stdio.h>

int main (){
    
    int x = 0, i = 2, p = 1;
    
    scanf("%d", &x);
    
    for(i; i <= x / 2; i++){
        if(x % i == 0){
            printf("nao"); 
            p = 0;
            break;
        }
    }
    
    if(x == 1 || x == 0){
        p = 0;
        printf("nao");
        
    }
    if(p == 1){
        
        printf("primo");
    }
    
    return 0;
}
