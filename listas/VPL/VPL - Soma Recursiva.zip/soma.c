#include <stdio.h>

// Função recursiva para calcular a soma dos elementos do vetor
int somaVetor(int vetor[], int indice, int tamanho) {
    if (indice >= tamanho) {
        return 0; // Caso base: índice maior ou igual ao tamanho do vetor
    } else {
        return vetor[indice] + somaVetor(vetor, indice + 1, tamanho); // Chamada recursiva
    }
}

int main() {
    int T;
    scanf("%d", &T);

    while (T--) {
        int n;
        scanf("%d", &n);

        int vetor[n];
        for (int i = 0; i < n; i++) {
            scanf("%d", &vetor[i]);
        }

        int resultado = somaVetor(vetor, 0, n);
        printf("%d\n", resultado);
    }

    return 0;
}
