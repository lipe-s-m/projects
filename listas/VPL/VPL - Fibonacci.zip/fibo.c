#include <stdio.h>

int fibonnaci(int n1);
int main(){
    
    int n, fibo;
    
    scanf("%d", &n);
    
    fibo = fibonnaci(n);
    printf("%d", fibo);
   
    
    
    
    return 0;
}
int fibonnaci(int n1){
    
    if(n1 == 0 || n1 == 1)
        return n1;
    else
    {
        return fibonnaci(n1-1) + fibonnaci(n1-2);
    }
}