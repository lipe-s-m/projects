#include <stdio.h>

int main(){
    
    int i = 0, t;
    int vetor[1000];
    
    scanf("%d", &t);
    
    for(i; i < t; i++)
    {
        scanf("%d", &vetor[i]);
    }
    
    for(i = i-1; i >=0; i--)
    {
        printf("%d ", vetor[i]);
    }
    return 0;
}