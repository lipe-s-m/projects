#include <stdio.h>

int main()
{
    int numero[60];
    int i = 0, t, a = 1, b = 0, c = 0;
    
    scanf("%d", &t);
    
    for(i = 0; i<t; i++)
    {
        scanf("%d", &numero[i]);
        
        for(int j = 1; j<numero[i]; j++)
        {
            c = a + b;
            b = a;
            a = c;
            
            
        }
        printf("\nfib(%d) = %d\n", numero[i], c);
        c = 0;
        a = 1;
        b = 0;
    }
    
    return 0;
}