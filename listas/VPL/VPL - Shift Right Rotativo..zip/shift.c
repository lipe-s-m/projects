#include <stdio.h>

int main() {
    int N;
    scanf("%d", &N);

    int numeros[N];

    for (int i = 0; i < N; i++) {
        scanf("%d", &numeros[i]);
    }

    // Realiza o shift right rotativo
    int ultimo = numeros[N - 1]; // Armazena o último elemento da sequência

    for (int i = N - 1; i > 0; i--) {
        numeros[i] = numeros[i - 1]; // Desloca os elementos uma posição para a direita
    }

    numeros[0] = ultimo; // Define o primeiro elemento como o valor armazenado na variável 'ultimo'

    // Imprime a sequência após o shift right rotativo
    for (int i = 0; i < N; i++) {
        printf("%d", numeros[i]);
        if (i < N - 1) {
            printf(" "); // Imprime um espaço entre os números (exceto após o último número)
        }
    }
    
    printf("\n");

    return 0;
}
