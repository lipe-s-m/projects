#include <stdio.h>
#include <string.h>

int main() {
    FILE *arquivo = fopen("arquivo.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    int numAlunos;
    fscanf(arquivo, "%d", &numAlunos);

    for (int i = 0; i < numAlunos; i++) {
        char nome[51];
        float nota1, nota2;
        float media;

        fscanf(arquivo, " %[^\n]", nome);
        fscanf(arquivo, "%f", &nota1);
        fscanf(arquivo, "%f", &nota2);

        media = (nota1 + nota2) / 2.0;

        if (media > 7.0) {
            printf("%s\n", nome);
        }
    }

    fclose(arquivo);
    return 0;
}
