#include <stdio.h>

char decimalToHexadecimal(int num) {
    if (num < 10)
        return num + '0'; // Converte dígitos 0-9 para caracteres '0'-'9'
    else
        return num - 10 + 'A'; // Converte dígitos 10-15 para caracteres 'A'-'F'
}

int main() {
    int V;
    scanf("%d", &V);

    char hexadecimal[9]; // O maior número em hexadecimal é FFFFFFFF (8 dígitos + '\0')
    int i = 0;

    while (V > 0) {
        int resto = V % 16;
        V /= 16;
        hexadecimal[i++] = decimalToHexadecimal(resto);
    }

    // Adiciona o caractere de fim-de-linha no final da string
    hexadecimal[i] = '\0';

    // Imprime a representação hexadecimal na ordem inversa (pois os dígitos foram obtidos na ordem inversa)
    for (int j = i - 1; j >= 0; j--)
        printf("%c", hexadecimal[j]);

    printf("\n");

    return 0;
}
