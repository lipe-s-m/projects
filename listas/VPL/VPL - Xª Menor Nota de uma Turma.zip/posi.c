#include <stdio.h>

int main(void)
{
    int quant, i, j, POS;
    scanf("%d %d", &quant, &POS);
    int notas[quant], menor[POS];

    for (i = 0; i < quant; i++)
    {
        scanf("%d", &notas[i]);
        if (i < POS)
            menor[i] = 10;
        if (notas[i] < menor[0])
        {
            menor[0] = notas[i];
        }
    }

    for (i = 1; i < POS; i++)
    {
        for (j = 0; j < quant; j++)
        {
            if (notas[j] < menor[i] && notas[j] > menor[i - 1])
            {
                menor[i] = notas[j];
            }
        }
    }

    printf("%d ", menor[POS - 1]);

    return 0;
}