#include <stdio.h>
#include <string.h>

// Função para calcular o número de LEDs necessários para um dígito
int ledsPorDigito(char digito) {
    switch (digito) {
        case '0':
            return 6;
        case '1':
            return 2;
        case '2':
            return 5;
        case '3':
            return 5;
        case '4':
            return 4;
        case '5':
            return 5;
        case '6':
            return 6;
        case '7':
            return 3;
        case '8':
            return 7;
        case '9':
            return 6;
        default:
            return 0;
    }
}

int main() {
    int N;
    scanf("%d", &N);

    while (N--) {
        char valor[101];
        scanf("%s", valor);

        int total_leds = 0;
        int len = strlen(valor);

        // Para cada dígito, adicionamos o número de LEDs necessários para formá-lo ao total_leds
        for (int i = 0; i < len; i++) {
            total_leds += ledsPorDigito(valor[i]);
        }

        printf("%d leds\n", total_leds);
    }

    return 0;
}
