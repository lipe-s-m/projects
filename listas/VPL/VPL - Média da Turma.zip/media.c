#include <stdio.h>

int main(){
    
    int n = 0, i = 0, nota = 0, cont = 0;
    float media = 0, somatorio = 0;
    
    scanf("%d", &n);
    
    for(i = 0; i < n; i++){
        
        scanf("%d ", &nota);
        
        if(nota <= 10){
            somatorio += nota;
            cont++;
        }
        else{
            
        }
    }
    
    media = somatorio / cont;
    
    printf("%.1f", media);
    
    return 0;
}
