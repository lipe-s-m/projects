#include <stdio.h>

char nome(char texto[20]);

int main(){
    
    int i = 0, j;
    char palavra[20];
    
    scanf("%s", palavra);
    
    nome(palavra);
    
    
    return 0;
}

char nome(char texto[20])
{
    int k = 0;
    for(k = 0; texto[k] != '\0'; k++)
    {
        if(texto[k] >= 'A' && texto[k] <= 'Z')
        {
            texto[k] = texto[k] - 'A' + 'a';
        }
        
    }
    if(texto[0] >= 'a' && texto[0] <= 'z')
        {
            texto[0] = texto[0] - 'a' + 'A';
        }
        
    printf("%s", texto);
    return 0;
}

