#include <stdio.h>

int main(){
    
    int n = 0, nota = 0, i = 0, cont = 0, temp = 11;
    
    scanf("%d", &n);
    
    for(i; i < n; i++){
        
        scanf("%d", &nota);

        
        if(nota <= 10 && nota >= 0){
            
            if(nota < temp){
                temp = nota;
            }
            
        }
        
    }
    
    printf("%d", temp);

    return 0;
}
