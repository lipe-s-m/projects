#include <stdio.h>

// Função recursiva para buscar o elemento no vetor
int buscarElemento(int vetor[], int elemento, int indice, int tamanho) {
    if (indice >= tamanho) {
        return -1; // Caso base: índice maior ou igual ao tamanho do vetor (elemento não encontrado)
    } else if (vetor[indice] == elemento) {
        return indice; // Caso base: elemento encontrado
    } else {
        return buscarElemento(vetor, elemento, indice + 1, tamanho); // Chamada recursiva
    }
}

int main() {
    int x, n;
    scanf("%d %d", &x, &n);

    int vetor[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }

    int resultado = buscarElemento(vetor, x, 0, n);
    printf("%d\n", resultado);

    return 0;
}

