#include <stdio.h>
#include <math.h>

int main(){
    
    double a, b, c, x = 0;
    
    scanf("%lf %lf %lf", &a, &b, &c);
    
    if(a < b){
        x = a;
        a = b;
        b = x;
    }
    
    if( a < c){
        x = a;
        a = c;
        c = x;
        
    }
    

    if(a >= (b + c)){
        printf("NAO FORMA TRIANGULO\n");
    }
    else if(pow(a, 2) == (pow(b, 2) + pow(c, 2))){
        printf("TRIANGULO RETANGULO\n");
        if(a == b && a == c){
            printf("TRIANGULO EQUILATERO\n");
        }
        else if(a == b || a == c || b == c){
            printf("TRIANGULO ISOSCELES\n");
        }
    }
    else if(pow(a, 2) > (pow(b, 2) + pow(c, 2))){
        printf("TRIANGULO OBTUSANGULO\n");
        if(a == b && a == c){
            printf("TRIANGULO EQUILATERO\n");
        }
        else if(a == b || a == c || b == c){
            printf("TRIANGULO ISOSCELES\n");
        }
    }
    else if(pow(a, 2) < (pow(b, 2) + pow(c, 2))){
        printf("TRIANGULO ACUTANGULO\n");
        if(a == b && a == c){
            printf("TRIANGULO EQUILATERO\n");
        }
        else if(a == b || a == c || b == c){
            printf("TRIANGULO ISOSCELES\n");
        }
    
    }

    
    
    
    
    return 0;
}
