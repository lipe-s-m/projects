#include <stdio.h>

int main(){
    
    int i = 0, t, j = 0;
    int vetor[1000];
    int cont[50];
    int n = 0;
    
    scanf("%d", &t);
    int m = 0;
    for(i=0; i < t; i++)
    {
        scanf("%d", &n);
        
        
        
        for(j=0; j < t; j++)
        {
            if(vetor[j] == n)
            {
                fflush(stdin);
                //printf("\n outro numero ");
                scanf("%d", &n);
            
                for(j; j >= 0; j--)
                {
                    if(vetor[j] == n)
                    {
                        fflush(stdout);
                        //printf("\n outro numero ");

                        scanf("%d", &n);
                    
                    }    
                }
            }
            
        }
        
       
        
            
        
        vetor[i] = n;
        }
    
    for(i = 0; vetor[i] != '\0'; i++)
    {
        printf("%d ", vetor[i]);
    }
    return 0;    
}