#include <stdio.h>

int main(){
    
    int x, teste = 0;
    scanf("%d", &x);
    teste = x % 2;

    if(teste == 1){
        printf("impar");
    }
    else{
        printf("par");
    }
    
    return 0;
    
    
}
