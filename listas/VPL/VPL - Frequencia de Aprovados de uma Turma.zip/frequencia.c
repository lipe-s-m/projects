#include <stdio.h>

int main(){
    
    int n = 0, nota = 0, MAX = 11, i = 0, cont = 0;
    
    scanf("%d", &n);
    
        for(i; i < n; i++){
            
            scanf("%d", &nota);
                
                if(nota >= 5 && nota < MAX){
                    
                    cont++;
                    
                }
                
            
            
            
        }
    
    printf("%d", cont);
    
    return 0;
}
