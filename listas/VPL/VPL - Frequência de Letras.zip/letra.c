#include <stdio.h>
#include <ctype.h>

// Função para contar a frequência das letras
void contarFrequencia(char *texto, int *frequencia) {
    while (*texto) {
        if (isalpha(*texto)) {
            frequencia[tolower(*texto) - 'a']++;
        }
        texto++;
    }
}

int main() {
    int N;
    scanf("%d", &N);

    while (N--) {
        char texto[201];
        scanf(" %[^\n]", texto);

        int frequencia[26] = {0}; // Inicializa o array de frequência com zeros

        contarFrequencia(texto, frequencia);

        int maxFrequencia = 0;
        for (int i = 0; i < 26; i++) {
            if (frequencia[i] > maxFrequencia) {
                maxFrequencia = frequencia[i];
            }
        }

        // Imprime as letras que têm a maior frequência
        for (int i = 0; i < 26; i++) {
            if (frequencia[i] == maxFrequencia) {
                printf("%c", 'a' + i);
            }
        }
        printf("\n");
    }

    return 0;
}
