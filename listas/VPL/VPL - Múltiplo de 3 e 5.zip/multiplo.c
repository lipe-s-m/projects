#include <stdio.h>

int main(){
    
    int x = 0, i = 1, n = 0, cont = 0, temp = 0, soma = 0;
    
    scanf("%d", &x);
    
        for(i; i < x; i++){
            
            if(i % 3 == 0){
                cont += i;
            }    
            else if(i % 5 == 0){
                temp += i;
            }
        }
    
    soma = cont + temp;
    printf("%d", soma);
    
    return 0;
}
