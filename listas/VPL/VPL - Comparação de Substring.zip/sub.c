#include <stdio.h>
#include <string.h>

// Função para calcular o máximo entre dois inteiros
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Função para encontrar o tamanho da maior subsequência comum (LCS)
int LCS(char *str1, char *str2) {
    int len1 = strlen(str1);
    int len2 = strlen(str2);

    // Remove a quebra de linha das strings
    if (str1[len1 - 1] == '\n') {
        str1[len1 - 1] = '\0';
        len1--;
    }
    if (str2[len2 - 1] == '\n') {
        str2[len2 - 1] = '\0';
        len2--;
    }

    int dp[len1 + 1][len2 + 1];

    // Inicializa a matriz com zeros
    for (int i = 0; i <= len1; i++) {
        for (int j = 0; j <= len2; j++) {
            dp[i][j] = 0;
        }
    }

    // Preenche a matriz usando a técnica de memoização
    for (int i = 1; i <= len1; i++) {
        for (int j = 1; j <= len2; j++) {
            if (str1[i - 1] == str2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    // O resultado estará no canto inferior direito da matriz
    return dp[len1][len2];
}

int main() {
    char str1[51], str2[51];
    fgets(str1, sizeof(str1), stdin);
    fgets(str2, sizeof(str2), stdin);

    int result = LCS(str1, str2);
    printf("%d\n", result);

    return 0;
}
