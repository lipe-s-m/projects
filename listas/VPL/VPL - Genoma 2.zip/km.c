#include <stdio.h>
#include <string.h>

int countOccurrences(char S[], char Sub[]) {
    int n = strlen(S);
    int m = strlen(Sub);
    int count = 0;

    if (m > n) {
        return 0; // Se a subsequência for maior que a sequência, retorna 0
    }

    for (int i = 0; i <= n - m; i++) {
        int j;
        for (j = 0; j < m; j++) {
            if (S[i + j] != Sub[j]) {
                break; // Se encontrar um caractere diferente, sai do loop
            }
        }
        if (j == m) {
            count++; // Se todos os caracteres da subsequência forem iguais, incrementa o contador
        }
    }

    return count;
}

int main() {
    char S[101], Sub[101];
    scanf("%s %s", S, Sub);

    int occurrences = countOccurrences(S, Sub);
    printf("%d\n", occurrences);

    return 0;
}
