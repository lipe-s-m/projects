#include<stdio.h>
int seq1(int n);
int sequen2(int n);
int nseq[200] = {0};

int main(){
        
    int c, n, i = 0, seq, seq2, j = 0;
    scanf("%d", &c);
    
    for(int conta = 0; conta < c; conta++)
    {
        scanf("%d", &n);
        seq1(n);
        seq2 = sequen2(n);
        if(seq2 == 1)
        
        {
            printf("Caso %d: %d numero\n", conta+1, seq2);
            while(j< seq2)
            {
                
                printf("%d ", nseq[j]);
                j++;
            }
        }
        else
        {
            printf("Caso %d: %d numeros\n", conta+1, seq2);
            while(j< seq2)
            {
                
                printf("%d ", nseq[j]);
                j++;
            }
        }
        printf("\n");
        j = 0;
        i = 0;
        
    }
        
    
    

        
    return 0;
}

int sequen2(int n){
    
    int output = 1;
    for(int i = 0; i <= n; i++)
    {
        output += i;

    }
    return output;
}

    


int seq1(int n){
    
    int i = 0, j = 0, index = 0;
    for(i; i <= n; i++)
    {
        if(n == 0)
        {
            nseq[index] = i;
            index++;
            
        }
        else
        {
            for(j; j<=n; j++)
            {
                if(j==1)
                {
                    nseq[index+1] = j;
                    index++;
                }
                else
                {
                    for(i= 0; i < j; i++)
                    {
                        nseq[index+1] = j;
                        index++;
                    }
                }
                    
            }
            
        }
    
    }
    
    
}
