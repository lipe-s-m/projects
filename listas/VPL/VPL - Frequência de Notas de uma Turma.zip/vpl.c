#include <stdio.h>

int main() {
    int N;
    scanf("%d", &N);

    int notas[11] = {0}; // Inicializa o array com zeros para cada nota (índice 0 a 10)

    for (int i = 0; i < N; i++) {
        int nota;
        scanf("%d", &nota);
        notas[nota]++;
    }

    // Imprime as frequências de cada nota
    for (int i = 0; i <= 10; i++) {
        printf("%d ", notas[i]);
    }
    
    printf("\n");

    return 0;
}
