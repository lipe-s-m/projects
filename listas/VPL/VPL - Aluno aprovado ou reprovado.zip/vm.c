#include <stdio.h>
#include <string.h>

int main() {
    FILE *arquivo = fopen("arquivo.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    char nome[50];
    float nota1, nota2, media;

    while (fscanf(arquivo, " %[^\n;];%f;%f;", nome, &nota1, &nota2) != EOF) {
        media = (nota1 + nota2) / 2.0;
        printf("%s %.1f %.1f %.1f %s\n", nome, nota1, nota2, media, (media >= 5.0) ? "aprovado" : "reprovado");
    }

    fclose(arquivo);
    return 0;
}
