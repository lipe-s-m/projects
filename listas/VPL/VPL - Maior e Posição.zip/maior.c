#include <stdio.h>

int main(){
    
    int n = 0, i = 0, temp = 0, MAX = 5, cont = 0;
    
    for(i; i < MAX; i++){
        
        scanf("%d", &n);
        
        if(n > temp){
            temp = n;
            cont = i + 1;
        }
        
    }
    
    printf("%d \n%d", temp, cont);
    
    
    return 0;
}

