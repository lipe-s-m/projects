#include <stdio.h>

int main(){
    
    int i = 0, n = 0;
    double x = 0, y = 0, z = 0, media = 0;
    
    scanf("%d", &n);
    
    for(i; i < n; i++){
        
        scanf("%lf %lf %lf", &x, &y, &z);
        
        media = ((x * 2) + (y * 3) + (z * 5)) / 10;
        printf(" \n%.1lf\n", media);
    }
    
    
    
    return 0;
}
