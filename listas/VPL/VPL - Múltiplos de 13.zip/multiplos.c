#include <stdio.h>

int main(){
    
    int x = 0, y = 0, mult = 0, temp = 0, soma = 0;
    
    scanf ("%d %d", &x, &y);
    
    if(x > y){
        temp = x;
        x = y;
        y = temp;
    }
    
    for(int i = x; i <= y; i++){
        
        if((i % 13) != 0){
            
            soma = i;
            mult = mult + soma;
        }
        
    }
    printf("%d", mult);
    
    
    return 0;
}
