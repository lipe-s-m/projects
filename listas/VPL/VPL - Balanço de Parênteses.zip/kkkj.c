#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX 1000

// Definição da estrutura da pilha
typedef struct {
    char items[MAX];
    int top;
} Stack;

// Função para inicializar a pilha
void initialize(Stack *stack) {
    stack->top = -1;
}

// Função para verificar se a pilha está vazia
bool isEmpty(Stack *stack) {
    return stack->top == -1;
}

// Função para verificar se a pilha está cheia
bool isFull(Stack *stack) {
    return stack->top == MAX - 1;
}

// Função para empilhar um elemento
void push(Stack *stack, char item) {
    if (!isFull(stack)) {
        stack->top++;
        stack->items[stack->top] = item;
    }
}

// Função para desempilhar um elemento
void pop(Stack *stack) {
    if (!isEmpty(stack)) {
        stack->top--;
    }
}

// Função para verificar se a quantidade de parênteses está correta
bool checkParentheses(const char *expression) {
    Stack stack;
    initialize(&stack);
    int length = strlen(expression);

    for (int i = 0; i < length; i++) {
        char currentChar = expression[i];
        if (currentChar == '(') {
            push(&stack, currentChar);
        } else if (currentChar == ')') {
            if (isEmpty(&stack)) {
                return false;
            }
            pop(&stack);
        }
    }

    return isEmpty(&stack);
}

int main() {
    char expression[MAX];
    fgets(expression, sizeof(expression), stdin);
    expression[strcspn(expression, "\n")] = '\0';

    if (checkParentheses(expression)) {
        printf("correct\n");
    } else {
        printf("incorrect\n");
    }

    return 0;
}
