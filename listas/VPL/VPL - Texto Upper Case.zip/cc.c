#include <stdio.h>
#include <ctype.h>

int main() {
    char texto[1000];
    fgets(texto, sizeof(texto), stdin);

    int i = 0;
    int primeiraLetra = 1; // Variável para controlar se é a primeira letra de uma palavra

    while (texto[i]) {
        if (isspace(texto[i])) {
            primeiraLetra = 1;
        } else {
            if (primeiraLetra) {
                texto[i] = toupper(texto[i]);
                primeiraLetra = 0;
            } else {
                texto[i] = tolower(texto[i]);
            }
        }
        i++;
    }

    printf("%s", texto);

    return 0;
}
