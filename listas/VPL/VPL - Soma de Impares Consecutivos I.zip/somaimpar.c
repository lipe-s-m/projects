#include <stdio.h>

int main(){
    
    int x = 0, y = 0, soma = 0;
    
    scanf("%d %d", &x, &y);
    
    while(x != y){
        
        if(x % 2 == 0 && y % 2 == 0){
            if(x > y){
                soma = x - 1;
                printf("%d", soma);
            }
        }
        
    }

    
    if(x % 2 == 0 && y % 2 == 0){
        if(x > y){
            
        }
        else if (y < x){
            
        }
        else{
            printf("%d", x-y);
        }
    }
    
    printf("%d %d", x, y);
    
    
    return 0;
}
