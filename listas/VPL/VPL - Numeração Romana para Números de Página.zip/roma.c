#include <stdio.h>
#include <string.h>

// Função para converter um dígito decimal para numeração romana
void converterDigito(int num, char um, char cinco, char dez, char* resultado) {
    switch (num) {
        case 0:
            break;
        case 1:
            *resultado++ = um;
            break;
        case 2:
            *resultado++ = um;
            *resultado++ = um;
            break;
        case 3:
            *resultado++ = um;
            *resultado++ = um;
            *resultado++ = um;
            break;
        case 4:
            *resultado++ = um;
            *resultado++ = cinco;
            break;
        case 5:
            *resultado++ = cinco;
            break;
        case 6:
            *resultado++ = cinco;
            *resultado++ = um;
            break;
        case 7:
            *resultado++ = cinco;
            *resultado++ = um;
            *resultado++ = um;
            break;
        case 8:
            *resultado++ = cinco;
            *resultado++ = um;
            *resultado++ = um;
            *resultado++ = um;
            break;
        case 9:
            *resultado++ = um;
            *resultado++ = dez;
            break;
        default:
            break;
    }
    *resultado = '\0';
}

// Função para converter um número inteiro para numeração romana
void converterParaRomano(int num, char* resultado) {
    converterDigito(num / 1000, 'M', '\0', '\0', resultado);
    num %= 1000;
    converterDigito(num / 100, 'C', 'D', 'M', resultado + strlen(resultado));
    num %= 100;
    converterDigito(num / 10, 'X', 'L', 'C', resultado + strlen(resultado));
    num %= 10;
    converterDigito(num, 'I', 'V', 'X', resultado + strlen(resultado));
}

int main() {
    int N;
    scanf("%d", &N);

    char romano[20]; // O maior número romano possível é "MMMMMMMMMCMXCIX" (10 + 900 + 90 + 9 = 999) (4 algarismos + '\0')
    converterParaRomano(N, romano);

    printf("%s\n", romano);

    return 0;
}
