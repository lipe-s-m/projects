#include <stdio.h>

int fatorial(int n1);
int main(){
    int n = 0, i = 0, fat;
    scanf("%d", &n);
    if(n >= 0 && n < 20)
    {
        fat = fatorial(n);
        printf("%d", fat);
        
        
    }
    
    return 0;
}

int fatorial(int n1)
{
    int i = 0, j = 0;
    if(n1 == 1 || n1 == 0)
    {
        
        return 1;
    }
    else
    {
        return n1 = n1 * fatorial(n1 - 1);
    
    }

}