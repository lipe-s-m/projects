#include <stdio.h>

// Função para realizar a ordenação por inserção e contar o número de trocas
int insertionSort(int arr[], int n) {
    int swaps = 0;
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
            swaps++;
        }
        arr[j + 1] = key;
    }

    return swaps;
}

int main() {
    int N;
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        int L;
        scanf("%d", &L);

        int arr[L];
        for (int j = 0; j < L; j++) {
            scanf("%d", &arr[j]);
        }

        int swaps = insertionSort(arr, L);
        printf("Optimal train swapping takes %d swaps.\n", swaps);
    }

    return 0;
}
